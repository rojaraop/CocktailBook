//
//  AppRouteView.swift
//  CocktailBook
//
//  Created by Rojarao Pothamsetty on 30/01/25.
//

import SwiftUI

struct AppRouteView: View {
    @ObservedObject private var viewModel = HomeViewModel()
    @State private var isLoading = true
    
    var body: some View {
        Group {
            if isLoading {
                SplashView()
            } else {
               HomeView(viewModel: viewModel)
            }
        }
        .onAppear {
            Task {
                await loadInitialData()
            }
        }
    }
    
    private func loadInitialData() async {
        async let fetchCocktailsTask: () = viewModel.fetchCocktails()
        await fetchCocktailsTask // Just waiting for few seconds till responce get
        isLoading = false
    }

}

#Preview {
    AppRouteView()
}
