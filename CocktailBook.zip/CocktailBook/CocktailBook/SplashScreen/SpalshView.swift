//
//  SpalshView.swift
//  CocktailBook
//
//  Created by Rojarao Pothamsetty on 30/01/25.
//

import SwiftUI

struct SplashView: View {
    var body: some View {
        ZStack {
            Color.white.edgesIgnoringSafeArea(.all)
            VStack {
                Image(systemName: "cup.and.saucer.fill")
                    .resizable()
                    .frame(width: 100, height: 100)
                    .foregroundColor(.purple)
                
                Text("Loading...")
                    .font(.headline)
                    .foregroundColor(.gray)
            }
        }
    }
}

#Preview {
    SplashView()
}
