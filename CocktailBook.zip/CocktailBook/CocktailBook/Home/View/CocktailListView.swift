//
//  CocktailListView.swift
//  CocktailBook
//
//  Created by Rojarao Pothamsetty on 30/01/25.
//

import SwiftUI

struct CocktailListView: View {
    /// - `Description:` View model  instance
    @ObservedObject var viewModel: HomeViewModel
    
    /// - `Description:` view body property wrapper
    var body: some View {
        if viewModel.cocktails != nil {
            // cocktail list view
            List(viewModel.filteredCocktails().sorted(by: { $0.cocktail.name < $1.cocktail.name })) { cocktailViewModel in
                NavigationLink(destination: DetailView(viewModel: cocktailViewModel)) {
                    HStack {
                        VStack(alignment: .leading) {
                            Text(cocktailViewModel.cocktail.name)
                                .font(.headline)
                                .foregroundColor(cocktailViewModel.isFavorite ? .purple : .primary)
                            Text(cocktailViewModel.cocktail.shortDescription)
                                .font(.subheadline)
                                .foregroundColor(.secondary)
                        }
                        Spacer()
                        
                        // favorite button
                        Button(action: {
                            viewModel.updateFavoriteStatus(for: cocktailViewModel)
                        }) {
                            Image(systemName: cocktailViewModel.isFavorite ? Constants.Image.favorite : Constants.Image.noFavorite)
                                .foregroundColor(cocktailViewModel.isFavorite ? .purple : .gray)
                        }
                        .buttonStyle(PlainButtonStyle())
                    }
                }
            }
            .listStyle(PlainListStyle())
        } else {
            Text(Constants.Home.loadingText)
                .foregroundColor(.gray)
        }
    }
}

#Preview {
    CocktailListView(viewModel: HomeViewModel())
}
