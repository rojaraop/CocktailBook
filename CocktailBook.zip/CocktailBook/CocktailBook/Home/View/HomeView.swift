//
//  HomeView.swift
//  CocktailBook
//
//  Created by Rojarao Pothamsetty on 30/01/25.
//

import SwiftUI

struct HomeView: View {
    
    /// - `Description:` View model  instance
    @ObservedObject var viewModel: HomeViewModel
    
    /// - `Description:` view body property wrapper
    var body: some View {
        NavigationView {
            VStack(spacing: 8) {
                filterPicker
                Divider()
                CocktailListView(viewModel: viewModel)
            }
            .navigationBarTitle("All Cocktails", displayMode: .large)
            .onAppear {
                viewModel.fetchCocktails()
            }
        }
    }
    
    // Filter Picker
    @ViewBuilder
    private var filterPicker: some View {
        Picker(Constants.Home.filterTitle, selection: $viewModel.selectedFilter) {
            Text(Constants.Home.allText).tag(Constants.Home.allText)
            Text(Constants.Home.alcoholicText).tag(Constants.Home.alcoholicText)
            Text(Constants.Home.nonAlcoholicText).tag(Constants.Home.nonAlcoholicText)
        }
        .pickerStyle(SegmentedPickerStyle())
        .padding(.horizontal)
        .cornerRadius(10)
    }
}

struct HomeViewView_Previews: PreviewProvider {
    static var previews: some View {
        HomeView(viewModel: HomeViewModel())
    }
}
