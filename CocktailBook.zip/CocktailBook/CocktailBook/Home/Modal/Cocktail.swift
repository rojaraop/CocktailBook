//
//  Cocktail.swift
//  CocktailBook
//
//  Created by Rojarao Pothamsetty on 30/01/25.
//

import Foundation

struct Cocktail: Identifiable, Codable {
    let id: String
    let name: String
    let type: String
    let shortDescription: String
    let longDescription: String
    let preparationMinutes: Int?
    let imageName: String
    let ingredients: [String]?
}
