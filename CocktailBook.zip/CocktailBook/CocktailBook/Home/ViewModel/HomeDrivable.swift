//
// HomeDrivable.swift
//  CocktailBook
//
//  Created by Rojarao Pothamsetty on 30/01/25.
//

import Foundation

protocol HomeDrivable: ObservableObject {
    // Properties
    var cocktails: [CocktailViewModel]? { get set }
    
    // Methods
    func fetchCocktails()
    func updateFavoriteStatus(for cocktailViewModel: CocktailViewModel)
    func filteredCocktails() -> [CocktailViewModel]
}
