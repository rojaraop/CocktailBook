//
//  HomeViewModel.swift
//  CocktailBook
//
//  Created by Rojarao Pothamsetty on 30/01/25.
//

import Foundation
import Combine

class HomeViewModel : HomeDrivable {
    
    // storing cocktails data
    @Published var cocktails: [CocktailViewModel]? = nil
    
    // storing error message
    @Published var errorMessage: String? = nil
    
    // storing filter state
    @Published var selectedFilter: String = Constants.Home.allText
    
    // Tracks if data is already loaded
    private var hasLoaded = false

    /// - `Description:`- Fetches cocktails  from json file
    func fetchCocktails() {
        // If the data has already been loaded, don't fetch it again
        if hasLoaded {
            self.errorMessage = nil
            return
        }

        // If the data has not been loaded, fetch it
        hasLoaded = true
        
        guard let url = Bundle.main.url(forResource: "sample", withExtension: "json") else {
            errorMessage = Constants.ErrorMessages.fileNotFound
            return
        }
        
        do {
            let data = try Data(contentsOf: url)
            let decodedCocktails = try JSONDecoder().decode([Cocktail].self, from: data)
            DispatchQueue.main.async {
                self.cocktails = decodedCocktails.map { CocktailViewModel(cocktail: $0)}
                self.errorMessage = nil
            }
        } catch {
            DispatchQueue.main.async {
                self.errorMessage = "\(Constants.ErrorMessages.failedToLoad) \(error.localizedDescription)"
            }
        }
    }
    
    /// - `Description:`- update favorite status when user click heart button
    func updateFavoriteStatus(for cocktailViewModel: CocktailViewModel) {
        objectWillChange.send()
        cocktailViewModel.isFavorite.toggle()
    }
    
    /// - `Description:`- To filter cocktails based on the selected filter
    func filteredCocktails() -> [CocktailViewModel] {
        guard let cocktails = cocktails else { return [] }
        
        switch selectedFilter {
        case Constants.Home.alcoholicText:
            return cocktails.filter { $0.cocktail.type.lowercased() == Constants.Home.alcoholicText.lowercased() }
        case Constants.Home.nonAlcoholicText:
            return cocktails.filter { $0.cocktail.type.lowercased() == Constants.Home.nonAlcoholicText.lowercased() }
        default:
            return cocktails
        }
    }
}
