//
//  DetailView.swift
//  CocktailBook
//
//  Created by Rojarao Pothamsetty on 30/01/25.
//

import SwiftUI

struct DetailView: View {
    
    /// - `Description:` View model  instance
    @ObservedObject var viewModel: CocktailViewModel
    
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16.0) {
                // Cocktail name
                Text(viewModel.cocktail.name)
                    .font(.title)
                    .bold()
                
                // Preparation minutes
                if let preparationMinutes = viewModel.cocktail.preparationMinutes {
                    HStack {
                        Image(systemName: Constants.Image.clock)
                            .foregroundColor(.primary)
                        Text("\(preparationMinutes) \(Constants.Detail.minutes)")
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                    }
                }
                
                // Cocktail Image
                Image(viewModel.cocktail.imageName)
                    .resizable()
                    .scaledToFill()
                    .frame(maxWidth: .infinity, maxHeight: 250.0)
                    .cornerRadius(12)
                
                // Cocktail long description
                Text(viewModel.cocktail.longDescription)
                    .font(.body)
                    .foregroundColor(.secondary)
                
                // Ingredients header
                Text(Constants.Detail.ingredientsTitle)
                    .font(.headline)
                
                // Ingredients list
                ForEach(viewModel.cocktail.ingredients ?? [], id: \.self) { ingredient in
                    HStack(alignment: .top) {
                        
                        Image(systemName: Constants.Image.play)
                            .foregroundColor(.secondary)
                        
                        Text(ingredient)
                            .font(.body)
                            .foregroundColor(.secondary)
                            .padding(.top, -5.0)
                        
                    }
                }
                
                Spacer()
                
            }
            .padding(.horizontal)
            .navigationBarTitle("", displayMode: .inline)
            .navigationBarItems(
                trailing:
                    // favourite button
                    Button(action: {
                        viewModel.isFavorite.toggle()
                    }) {
                        Image(systemName: viewModel.isFavorite ? Constants.Image.favorite : Constants.Image.noFavorite)
                            .foregroundColor(viewModel.isFavorite ? .purple : .gray)
                    }
            )
        }
    }
}

